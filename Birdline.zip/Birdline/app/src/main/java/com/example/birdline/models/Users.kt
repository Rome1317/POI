package com.poi.camppus.models

class Users(var id:String,
            var names:String,
            var surname:String,
            var emails:String,
            var password :String,
            var image:String?) {
}