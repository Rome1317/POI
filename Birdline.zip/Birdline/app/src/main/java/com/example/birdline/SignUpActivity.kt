package com.example.birdline

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AlertDialog
import com.google.firebase.auth.FirebaseAuth

class SignUpActivity : AppCompatActivity() {

    lateinit var btnSignUp: Button
    lateinit var etUser : EditText
    lateinit var etEmail : EditText
    lateinit var etPass : EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signup)

        // Setup
        setup()


    }

    private fun setup(){
        title = "Autenticación"

        // Sign Up
        btnSignUp = findViewById<Button>(R.id.btnRegister)
        etUser = findViewById<EditText>(R.id.etUser)
        etEmail = findViewById<EditText>(R.id.etEmail)
        etPass = findViewById<EditText>(R.id.etPassword)

        btnSignUp.setOnClickListener(){
            if (etEmail.text.isNotEmpty() && etPass.text.isNotEmpty() && etUser.text.isNotEmpty()){
                FirebaseAuth.getInstance().createUserWithEmailAndPassword(etEmail.text.toString(),
                        etPass.text.toString()).addOnCompleteListener(){

                    if(it.isSuccessful){
                        showHome(it.result?.user?.email ?: "")
                    }else{
                        showAlert()
                    }
                }
            }

        }



    }

    private fun showAlert(){
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Error")
        builder.setMessage("Se ha producido un error autenticando el usuario")
        builder.setPositiveButton("Aceptar", null)
        val dialog: AlertDialog = builder.create()
        dialog.show()
    }

    private fun showHome(email: String){
        val intent: Intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
        finish()
    }
}