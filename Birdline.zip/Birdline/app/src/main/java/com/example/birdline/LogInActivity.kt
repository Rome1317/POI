package com.example.birdline

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AlertDialog
import com.google.firebase.auth.FirebaseAuth

class LogInActivity : AppCompatActivity() {

    lateinit var btnLogin: Button
    lateinit var etEmail : EditText
    lateinit var etPass : EditText


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        // Setup
        setup()
    }

    private fun setup(){
        title = "Autenticación"

        // Sign Up
        btnLogin = findViewById<Button>(R.id.btnRegister)
        etEmail = findViewById<EditText>(R.id.etEmail)
        etPass = findViewById<EditText>(R.id.etPassword)

        btnLogin.setOnClickListener(){
            if (etEmail.text.isNotEmpty() && etPass.text.isNotEmpty()){
                FirebaseAuth.getInstance()
                        .signInWithEmailAndPassword(etEmail.text.toString(),
                        etPass.text.toString()).addOnCompleteListener(){

                    if(it.isSuccessful){
                        showHome(it.result?.user?.email ?: "")
                    }else{
                        showAlert()
                    }
                }
            }

        }
    }

    private fun showAlert(){
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Error")
        builder.setMessage("Se ha producido un error autenticando el usuario")
        builder.setPositiveButton("Aceptar", null)
        val dialog: AlertDialog = builder.create()
        dialog.show()
    }

    private fun showHome(email: String){
        val intent: Intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
        finish()
    }
}