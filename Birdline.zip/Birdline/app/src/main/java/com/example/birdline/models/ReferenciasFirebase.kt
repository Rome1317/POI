package com.poi.camppus.models

enum class ReferenciasFirebase {
    USERS,CHATS, MESSAGES
}