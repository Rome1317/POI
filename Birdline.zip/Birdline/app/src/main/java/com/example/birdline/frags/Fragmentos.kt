package com.example.birdline.frags

import androidx.fragment.app.Fragment
import com.example.birdline.R

class FragmentoA: Fragment(R.layout.fragmento_a){
}

class FragmentoB: Fragment(R.layout.fragment_contacts_list){
}

class FragmentoC: Fragment(R.layout.fragment_chat){
}

class FragmentoD: Fragment(R.layout.fragmento_d){
}

class FragmentoE: Fragment(R.layout.fragmento_e){
}

class FragmentoF: Fragment(R.layout.fragmento_f){
}

class FragmentoG: Fragment(R.layout.fragmento_g){
}